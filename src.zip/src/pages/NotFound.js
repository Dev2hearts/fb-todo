const NotFound = () => {
  return (
    <div className="p-6 mt-5 shadow rounded bg-slate-200">NotFound</div>
  )
}
export default NotFound